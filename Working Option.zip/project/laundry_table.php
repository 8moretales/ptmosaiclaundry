<div id="orders-table" class="table-container">
    <?php include 'get_orders.php'; ?>
</div>