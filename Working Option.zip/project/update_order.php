<?php
require_once 'config.php';

header('Content-Type: application/json');

try {
    $id = $_POST['id'] ?? null;
    $action = $_POST['action'] ?? null;
    
    if (!$id || !$action) {
        throw new Exception('Missing required parameters');
    }
    
    if ($action === 'date') {
        $date = $_POST['date'] ?? null;
        if (!$date) throw new Exception('Missing date parameter');
        
        // Convert date from d/m/Y to MySQL format
        $formatted_date = DateTime::createFromFormat('d/m/Y', $date);
        if (!$formatted_date) {
            throw new Exception('Invalid date format');
        }
        $mysql_date = $formatted_date->format('Y-m-d');
        
        $stmt = $conn->prepare("
            UPDATE laundry_orders 
            SET delivery_date = ?
            WHERE id = ?
        ");
        $stmt->bind_param("si", $mysql_date, $id);
        
    } elseif ($action === 'status') {
        $delivered = $_POST['delivered'] ?? null;
        if ($delivered === null) throw new Exception('Missing delivered parameter');
        
        $delivery_date = $delivered ? date('Y-m-d') : null;
        
        $stmt = $conn->prepare("
            UPDATE laundry_orders 
            SET delivered = ?,
                delivery_date = ?
            WHERE id = ?
        ");
        $stmt->bind_param("isi", $delivered, $delivery_date, $id);
        
    } else {
        throw new Exception('Invalid action');
    }
    
    if (!$stmt->execute()) {
        throw new Exception($stmt->error);
    }
    
    // Get updated order for webhook
    $result = $conn->query("SELECT * FROM laundry_orders WHERE id = $id");
    $order = $result->fetch_assoc();
    
    // Format delivery_date for display if it exists
    if ($order['delivery_date']) {
        $order['delivery_date'] = date('d/m/Y', strtotime($order['delivery_date']));
    }
    
    echo json_encode([
        'success' => true,
        'order' => $order
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>