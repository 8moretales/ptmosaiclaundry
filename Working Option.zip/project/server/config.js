// Database configuration
export const DB_CONFIG = {
  host: 'ptmosaic.com',
  database: 'kntgfkmy_laundrytracker',
  user: 'kntgfkmy_laundtrack2024',
  password: '@*dPo@+c5@PQ',
  ssl: false
};