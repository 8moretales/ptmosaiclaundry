<?php
require_once 'config.php';

header('Content-Type: application/json');

try {
    // Get the latest order number
    $result = $conn->query("SELECT MAX(order_number) as max_number FROM laundry_orders");
    $row = $result->fetch_assoc();
    $newOrderNumber = ($row['max_number'] ?? 10000) + 1;
    
    // Calculate total garments
    $total_garments = 0;
    $garment_fields = ['shirts', 'tshirts', 'jeans', 'trousers', 'shorts', 
                       'inner_wear', 'socks', 'womens_dresses', 'coat_jacket', 
                       'cap_hat', 'other'];
    
    foreach ($garment_fields as $field) {
        $total_garments += (int)($_POST[$field] ?? 0);
    }
    
    // Format current date time as d/m/Y H:i
    $order_date = date('d/m/Y H:i');
    
    // Prepare and execute insert query
    $stmt = $conn->prepare("
        INSERT INTO laundry_orders (
            order_number, villa_name, guest_name, order_date,
            total_garments, shirts, tshirts, jeans, trousers,
            shorts, inner_wear, socks, womens_dresses,
            coat_jacket, cap_hat, other, notes
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    if (!$stmt) {
        throw new Exception($conn->error);
    }
    
    $stmt->bind_param("isssiiiiiiiiiiiss",
        $newOrderNumber,
        $_POST['villa_name'],
        $_POST['guest_name'],
        $order_date,
        $total_garments,
        $_POST['shirts'] ?? 0,
        $_POST['tshirts'] ?? 0,
        $_POST['jeans'] ?? 0,
        $_POST['trousers'] ?? 0,
        $_POST['shorts'] ?? 0,
        $_POST['inner_wear'] ?? 0,
        $_POST['socks'] ?? 0,
        $_POST['womens_dresses'] ?? 0,
        $_POST['coat_jacket'] ?? 0,
        $_POST['cap_hat'] ?? 0,
        $_POST['other'] ?? 0,
        $_POST['notes'] ?? ''
    );
    
    if (!$stmt->execute()) {
        throw new Exception($stmt->error);
    }
    
    // Get the inserted order
    $orderId = $stmt->insert_id;
    $result = $conn->query("SELECT * FROM laundry_orders WHERE id = $orderId");
    $order = $result->fetch_assoc();
    
    echo json_encode([
        'success' => true,
        'order' => $order
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>