<?php
define('DB_HOST', 'ptmosaic.com');
define('DB_USER', 'kntgfkmy_laundtrack2024');
define('DB_PASS', '@*dPo@+c5@PQ');
define('DB_NAME', 'kntgfkmy_laundrytracker');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>