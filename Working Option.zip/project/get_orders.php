<?php
require_once 'config.php';

$query = "SELECT * FROM laundry_orders ORDER BY delivered ASC, order_date DESC";
$result = $conn->query($query);
?>

<table class="table">
    <thead>
        <tr>
            <th>Order #</th>
            <th>Order Date</th>
            <th>Villa</th>
            <th>Guest</th>
            <th>Total Items</th>
            <th>Delivery Date</th>
            <th>Delivered</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($order = $result->fetch_assoc()): ?>
        <tr class="<?= $order['delivered'] ? 'delivered' : '' ?>">
            <td><?= htmlspecialchars($order['order_number']) ?></td>
            <td><?= htmlspecialchars($order['order_date']) ?></td>
            <td><?= htmlspecialchars($order['villa_name']) ?></td>
            <td><?= htmlspecialchars($order['guest_name']) ?></td>
            <td><?= htmlspecialchars($order['total_garments']) ?></td>
            <td>
                <input type="text" 
                       class="form-input date-picker" 
                       value="<?= $order['delivery_date'] ? date('d/m/Y', strtotime($order['delivery_date'])) : '' ?>"
                       data-order-id="<?= $order['id'] ?>">
            </td>
            <td>
                <input type="checkbox" 
                       <?= $order['delivered'] ? 'checked' : '' ?>
                       onchange="updateDeliveryStatus(this, <?= $order['id'] ?>)">
            </td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<script>
flatpickr(".date-picker", {
    dateFormat: "d/m/Y",
    allowInput: true,
    onChange: function(selectedDates, dateStr, instance) {
        const input = instance.input;
        updateDeliveryDate(input);
    }
});

async function updateDeliveryDate(input) {
    const orderId = input.dataset.orderId;
    const date = input.value;
    
    try {
        const response = await fetch('update_order.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=date&id=${orderId}&date=${date}`
        });
        
        if (!response.ok) throw new Error('Failed to update delivery date');
        
        const result = await response.json();
        if (!result.success) throw new Error(result.message);
    } catch (error) {
        Swal.fire({
            icon: 'error',
            title: 'Error!',
            text: error.message
        });
    }
}

async function updateDeliveryStatus(checkbox, orderId) {
    try {
        const response = await fetch('update_order.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `action=status&id=${orderId}&delivered=${checkbox.checked ? 1 : 0}`
        });
        
        if (!response.ok) throw new Error('Failed to update delivery status');
        
        const result = await response.json();
        if (!result.success) throw new Error(result.message);
        
        if (checkbox.checked) {
            // Send to webhook
            await fetch('https://hook.eu1.make.com/1bkuivimuxrrkveycih7kqsu35atdomg', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(result.order)
            });
        }
        
        // Refresh table
        const tableHtml = await fetch('get_orders.php').then(r => r.text());
        document.getElementById('orders-table').innerHTML = tableHtml;
    } catch (error) {
        checkbox.checked = !checkbox.checked;
        Swal.fire({
            icon: 'error',
            title: 'Error!',
            text: error.message
        });
    }
}
</script>